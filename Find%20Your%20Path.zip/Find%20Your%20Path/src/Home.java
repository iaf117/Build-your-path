import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class Home extends JFrame {

	private JPanel contentPane;
	private JTextField id;
	private JTextField password;

	public static String username="";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
					Ids.rundb();
					Ids.getDataFromDB();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
		    public void run() {
		        Ids.updte();
		      
		    }
		}));
	}
	
	

	/**
	 * Create the frame.
	 */
	public Home() {
		setTitle("Main");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 786, 484);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Build Your Own Path");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(249, 45, 254, 22);
		contentPane.add(lblNewLabel);
		
		JLabel lblThisProgramAims = new JLabel("This program aims to help you in your future career and develope new skills");
		lblThisProgramAims.setHorizontalAlignment(SwingConstants.CENTER);
		lblThisProgramAims.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblThisProgramAims.setBounds(69, 88, 600, 22);
		contentPane.add(lblThisProgramAims);
		
		JLabel lblSignInAs = new JLabel("sign in as ?");
		lblSignInAs.setHorizontalAlignment(SwingConstants.CENTER);
		lblSignInAs.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSignInAs.setBounds(249, 160, 254, 22);
		contentPane.add(lblSignInAs);
		
		JRadioButton radioUser = new JRadioButton("user");
		radioUser.setBounds(308, 211, 63, 23);
		contentPane.add(radioUser);
		
		JRadioButton radioPartner = new JRadioButton("partner");
		radioPartner.setBounds(387, 211, 79, 23);
		contentPane.add(radioPartner);
		
		ButtonGroup btnGroup=new ButtonGroup();
		btnGroup.add(radioPartner);
		btnGroup.add(radioUser);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setBounds(196, 283, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("password");
		lblNewLabel_1_1.setBounds(196, 307, 57, 14);
		contentPane.add(lblNewLabel_1_1);
		
		id = new JTextField();
		id.setBounds(263, 277, 187, 20);
		contentPane.add(id);
		id.setColumns(10);
		
		password = new JTextField();
		password.setColumns(10);
		password.setBounds(263, 304, 187, 20);
		contentPane.add(password);
		
		JButton btn_signIn = new JButton("sign in");
		btn_signIn.setBounds(318, 347, 89, 23);
		btn_signIn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String idString=id.getText();
				String passString=password.getText();
				if (radioPartner.isSelected()) {
					try {
						if (newPartner.verify(idString, passString)) {
							newOffer.run();
							dispose();
						}
						else {
							JOptionPane.showMessageDialog(null, "Incorrect Id or password");
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				else if (radioUser.isSelected()) {
					try {
						if (newUser.verify(idString, passString)) {
							newApply.run();
							username=idString;
							dispose();
						}
						else {
							JOptionPane.showMessageDialog(null, "Incorrect Id or password");
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				else {
					JOptionPane.showMessageDialog(null, "choose partner or user");
				}
				
				
			}
		});
		contentPane.add(btn_signIn);
		
		JButton btn_createNew = new JButton("create new");
		btn_createNew.setBounds(423, 411, 102, 23);
		btn_createNew.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				 createNew.run();
				 username=id.getText();
				 dispose();
				
			}
		});
		contentPane.add(btn_createNew);
		
		JLabel lblYouDontHave = new JLabel("you dont have an account?");
		lblYouDontHave.setHorizontalAlignment(SwingConstants.CENTER);
		lblYouDontHave.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblYouDontHave.setBounds(239, 410, 187, 22);
		contentPane.add(lblYouDontHave);
	}
}
