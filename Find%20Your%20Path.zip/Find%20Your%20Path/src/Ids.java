import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Ids {
	 private static Connection con;
	 private static boolean hasData = false; 
	 public static ResultSet iduserResultSet;
	 public static ResultSet idpartneResultSet;
	
	
	public static int idUser=1;
	public static int idPartner=1;

	
	
	public static void getDataFromDB() throws ClassNotFoundException {
		try {
			
			idUser=iduserResultSet.getInt(1);
			
			idPartner=idpartneResultSet.getInt(1);
			
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} 
	
	
	 private static void getConnection() throws ClassNotFoundException, SQLException {
		  // sqlite driver
		  Class.forName("org.sqlite.JDBC");
		  // database path, if it's new database, it will be created in the project folder
		  con = DriverManager.getConnection("jdbc:sqlite:data/Ids.db");
		 initialise();
		 //initialise2();
	 }
	
	 private static void initialise() throws SQLException {
		 if( !hasData ) {
			 hasData = true;
			 // check for database table
			 Statement state = con.createStatement();
			 ResultSet res = state.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='user'");
			 if( !res.next()) {
				 
				 System.out.println("Building the User table with prepopulated values.");
				 // need to build the table
				  Statement state2 = con.createStatement();
				  state2.executeUpdate("create table user(id integer,"
				    + "Name varchar(60)," + "vlue integer(60)," + "primary key (id));");

				  // inserting data
				  PreparedStatement prep1 = con.prepareStatement("insert into user values(?,?,?);");
				  prep1.setString(2, "iduserResultSet");
				  prep1.setString(3, ""+idUser);
				  prep1.execute();
				  
				  PreparedStatement prep2 = con.prepareStatement("insert into user values(?,?,?);");
				  prep2.setString(2, "idpartneResultSet");
				  prep2.setString(3, ""+idPartner);
				  prep2.execute();
				  
				  
			 }
			 
		 }
	 }
	 
 public static void rundb() {
		 
		 if(con == null) {
			 // get connection
			 try {
				getConnection();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
				
			
			try {
				idpartneResultSet = con.createStatement().executeQuery("select vlue from user where Name is 'idpartneResultSet' ");
				iduserResultSet = con.createStatement().executeQuery("select vlue from user where Name is 'iduserResultSet' ");
			
				
				  
			  } catch (Exception e) {
				  e.printStackTrace();
			  }

		}
 
 
 public static void updte() {
	 try {
		 con.createStatement().executeUpdate("UPDATE user SET vlue = "+idUser+" where Name is 'iduserResultSet' ");
		 con.createStatement().executeUpdate("UPDATE user SET vlue = "+idPartner+" where Name is 'idpartneResultSet' ");

		 
		 
		
		 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
 }
}
	


