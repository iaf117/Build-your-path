import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class availableCourses extends JFrame {

	private static JComboBox comboBox=new JComboBox();
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					availableCourses frame = new availableCourses();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public availableCourses() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAvailableCourses = new JLabel("available courses");
		lblAvailableCourses.setHorizontalAlignment(SwingConstants.CENTER);
		lblAvailableCourses.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAvailableCourses.setBounds(112, 72, 210, 16);
		contentPane.add(lblAvailableCourses);
		
		comboBox.setBounds(73, 111, 283, 22);
		try {
			comboBox.setModel(new DefaultComboBoxModel(newCourse.getItems().toArray()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		contentPane.add(comboBox);
		
		comboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				newCourse course=null;
				String name = String.valueOf(comboBox.getSelectedItem());
				try {
					 course= newCourse.getCourseData(name);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, "Course Details: \nCourse name: "+course.getCourseNameString()+"\n"+"Course goal: "+course.getCourseGoalString()+"\n"+"Course date: "
						+course.getDateString()+"\n"+"Course Hours: "+course.getHoursInt()+"\n"+"Course Instructor: "+course.getInstructorString());
				
			}
		});
		
		
		JButton btnNewButton = new JButton("Apply");
		btnNewButton.setBounds(173, 161, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Calendar calendar = Calendar.getInstance();
				calendar.add(Calendar.DAY_OF_YEAR, 0);
	 			Date today = calendar.getTime();
	 			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	 			String todayAsString = dateFormat.format(today);
			newApply.insert(Ids.idUser, Home.username, "Course", todayAsString);
			Ids.idUser++;
			JOptionPane.showMessageDialog(null, "Submitted!");
				
			}
		});
		contentPane.add(btnNewButton);
	}
	
	

}
