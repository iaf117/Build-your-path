import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class availableJobs extends JFrame {

	private JPanel contentPane;
	private static JComboBox comboBox=new JComboBox();

	/**
	 * Launch the application.
	 */
	public static void run() {
				try {
					availableJobs frame = new availableJobs();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public availableJobs() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAvailablejobs = new JLabel("available jobs");
		lblAvailablejobs.setHorizontalAlignment(SwingConstants.CENTER);
		lblAvailablejobs.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAvailablejobs.setBounds(112, 72, 210, 16);
		contentPane.add(lblAvailablejobs);
		
		comboBox.setBounds(73, 111, 283, 22);
		try {
			comboBox.setModel(new DefaultComboBoxModel(newJob.getItems().toArray()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		contentPane.add(comboBox);
		
		
       comboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				newJob job=null;
				String name = String.valueOf(comboBox.getSelectedItem());
				try {
					job= newJob.getJobData(name);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, "Job Details: \nJob type: "+job.getTypeString()+"\n"+"Job location: "+job.getLocationString()+"\n"+"Gender: "
						+job.getGenderString()+"\n"+"Job salary: "+job.getSalaryDouble()+"\n"+"Job describtion: "+job.getJobDescString());
				
			}
		});
		
		
		JButton btnNewButton = new JButton("Apply");
		btnNewButton.setBounds(173, 161, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Calendar calendar = Calendar.getInstance();
				calendar.add(Calendar.DAY_OF_YEAR, 0);
	 			Date today = calendar.getTime();
	 			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	 			String todayAsString = dateFormat.format(today);
			newApply.insert(Ids.idUser, Home.username, "Job", todayAsString);
			Ids.idUser++;
			JOptionPane.showMessageDialog(null, "Submitted!");
				
			}
		});
		contentPane.add(btnNewButton);
	}

}
