import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class availableVolunteers extends JFrame {

	private JPanel contentPane;
	private static JComboBox comboBox=new JComboBox();

	/**
	 * Launch the application.
	 */
	public static void run() {
				try {
					availableVolunteers frame = new availableVolunteers();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	

	/**
	 * Create the frame.
	 */
	public availableVolunteers() {
		setTitle("available Voluntters");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAvailableCourses = new JLabel("available volunteer");
		lblAvailableCourses.setHorizontalAlignment(SwingConstants.CENTER);
		lblAvailableCourses.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAvailableCourses.setBounds(112, 72, 210, 16);
		contentPane.add(lblAvailableCourses);
		
		comboBox.setBounds(73, 111, 283, 22);
		try {
			comboBox.setModel(new DefaultComboBoxModel(newVoulnteer.getItems().toArray()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		contentPane.add(comboBox);
		
		
		
		  comboBox.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					newVoulnteer voulnteer=null;
					String name = String.valueOf(comboBox.getSelectedItem());
					try {
						voulnteer= newVoulnteer.getVoulnteerData(name);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "voulnteer Information: \nVoulnteer detail: "+voulnteer.getDetailString()+"\n"+"voulnteer tasks: "+voulnteer.getTaskString()+"\n"+"date: "
							+voulnteer.getDateString()
							+"\n"+"voulnteer city: "+voulnteer.getCityString()+"\n"+"voulnteer place: "+voulnteer.getPlaceString()
							+"\n"+"voulnteer seat number: "+voulnteer.getSeatNumberString()+"\n"+"voulnteer qualification: "+voulnteer.getQualificationString()
							+"\n"+"voulnteer enrollment: "+voulnteer.getEnrollmentString()+"\n"+"voulnteer supportProvided: "+voulnteer.getSupportProvidedString()
							+"\n"+"is Remote?: "+voulnteer.getIsRemoteString()+"\n"+"is Urgent? : "+voulnteer.getIsUrgentString()
							+"\n"+"requires interview?: "+voulnteer.getInterviewString()+"\n"+"voulnteer gender: "+voulnteer.getGenderString()
							+"\n"+"required age: "+voulnteer.getRequiredAgeInt());
					
				}
			});
		
		
		
		
		
		
		JButton btnNewButton = new JButton("Apply");
		btnNewButton.setBounds(173, 161, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Calendar calendar = Calendar.getInstance();
				calendar.add(Calendar.DAY_OF_YEAR, 0);
	 			Date today = calendar.getTime();
	 			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	 			String todayAsString = dateFormat.format(today);
			newApply.insert(Ids.idUser, Home.username, "Volunteer", todayAsString);
			Ids.idUser++;
			JOptionPane.showMessageDialog(null, "Submitted!");
			}
		});
		contentPane.add(btnNewButton);
	}

}
