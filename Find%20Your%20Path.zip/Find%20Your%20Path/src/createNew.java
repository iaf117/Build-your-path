import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import javax.swing.JButton;

public class createNew extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					createNew frame = new createNew();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		
	

	/**
	 * Create the frame.
	 */
	public createNew() {
		setTitle("Create New");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCreateNewAs = new JLabel("create new as ?");
		lblCreateNewAs.setBounds(0, 79, 424, 16);
		lblCreateNewAs.setHorizontalAlignment(SwingConstants.CENTER);
		lblCreateNewAs.setFont(new Font("Tahoma", Font.BOLD, 13));
		contentPane.add(lblCreateNewAs);
		
		JButton btn_user = new JButton("user");
		btn_user.setBounds(104, 127, 77, 23);
		btn_user.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				newUser.run();
				dispose();
				
			}
		});
		contentPane.add(btn_user);
		
		JButton btn_partner = new JButton("partner");
		btn_partner.setBounds(224, 127, 89, 23);
		btn_partner.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				newPartner.run();
				dispose();
				
			}
		});
		contentPane.add(btn_partner);
	}

}
