import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class newApply extends JFrame {

	private JPanel contentPane;

	private String date;

	private String type;

	private String username;

	private static Connection con;
	 private static boolean hasData = false;
	
	 
	 private static void getConnection() throws ClassNotFoundException, SQLException {
		  // sqlite driver
		  Class.forName("org.sqlite.JDBC");
		  // database path, if it's new database, it will be created in the project folder
		  con = DriverManager.getConnection("jdbc:sqlite:data/applications.db");
		 initialise();
		 //initialise2();
		 
		 
		 
	 }
	 
	 private static void initialise() throws SQLException {
		 if( !hasData ) {
			 hasData = true;
			 // check for database table
			 Statement state = con.createStatement();
			 ResultSet res = state.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='user'");
			 if( !res.next()) {
				 
				 System.out.println("Building the User table with prepopulated values.");
				 // need to build the table
				  Statement state2 = con.createStatement();
				  state2.executeUpdate("create table user(id integer,"
				    + "username Varchar(30)," + "type  Varchar(20),"+ "date  Varchar(30),"
				    + "primary key (id));");

				
			 }
			 
		 }
	 }
	 
	 public static void insert(int id, String username,String type,String date) {
			
				if(con == null) {
					 // get connection
					 try {
						getConnection();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }
			try {
				Statement state = con.createStatement();
				state.executeUpdate("INSERT INTO user " + "VALUES ('"+id+"','"+username+"','"+type+"','"+date+"')");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
	
	 public static ArrayList<newApply> getApps() throws SQLException {
		 
		 ArrayList<newApply> apps=new ArrayList <>();
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
			try {
				  
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery("Select * from user");
				
				                
				// Iterate through the data in the result set and display it. 

				while (rs.next()) {
				//Print one row          
				//for(int i = 1 ; i = columnsNumber; i++){

				     newApply app1= new newApply(rs.getString("username"), rs.getString("type"), rs.getString("date"));
				     apps.add(app1);

				     
				//}

				    

				    }
				
		  } catch (Exception e) {
			  e.printStackTrace();
		  }
			
			return apps;
		}

			public static void run() {
				try {
					newApply frame = new newApply();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

	/**
	 * Create the frame.
	 */
	public newApply() {
		setTitle("New Apply (For User)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 412, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddNewOffer = new JLabel("New apply");
		lblAddNewOffer.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddNewOffer.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAddNewOffer.setBounds(86, 41, 210, 16);
		contentPane.add(lblAddNewOffer);
		
		JButton btn_course = new JButton("course");
		btn_course.setBounds(147, 84, 103, 23);
		btn_course.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				availableCourses.run();
				
			}
		});
		contentPane.add(btn_course);
		
		JButton btnJob = new JButton("job");
		btnJob.setBounds(147, 118, 103, 23);
		
		btnJob.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				availableJobs.run();
				
				
			}
		});
		contentPane.add(btnJob);
		
		JButton btnVoulnteer = new JButton("volunteer ");
		btnVoulnteer.setBounds(147, 152, 103, 23);
		btnVoulnteer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				availableVolunteers.run();
			
				
			}
		});
		contentPane.add(btnVoulnteer);
		
		JButton btnShowRegisteredUsers = new JButton("show older application ");
		btnShowRegisteredUsers.setBounds(110, 217, 168, 23);
		btnShowRegisteredUsers.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			applications.run();	
				
			}
		});
		contentPane.add(btnShowRegisteredUsers);
		
		JLabel lblNewLabel = new JLabel("or");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(57, 221, 46, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("log out");
		btnNewButton.setBounds(297, 297, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Home.main(null);
				dispose();
			}
		});
		contentPane.add(btnNewButton);
		
	}
	public newApply(String username, String type, String date) {
		this.username=username; this.type=type; this.date=date;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTypee() {
		return type;
	}

	public void setTypee(String type) {
		this.type = type;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}
