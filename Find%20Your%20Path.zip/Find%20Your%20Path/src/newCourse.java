import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

public class newCourse extends JFrame {

	private JPanel contentPane;
	private JTextField courseName;
	private JTextField courseGoal;
	private JTextField date;
	private JTextField hours;
	private JTextField instructor;
	
	private String courseNameString;
	private String courseGoalString;
	private String dateString;
	private int hoursInt;
	private String instructorString;
	public newCourse(String courseNameString,String courseGoalString,String dateString,int hoursInt,String instructorString) {
		this.courseNameString=courseNameString;
		this.courseGoalString=courseGoalString;
		this.dateString=dateString;
		this.hoursInt=hoursInt;
		this.instructorString=instructorString; 
	}
	
	private static Connection con;
	 private static boolean hasData = false;
	
	 
	 private static void getConnection() throws ClassNotFoundException, SQLException {
		  // sqlite driver
		  Class.forName("org.sqlite.JDBC");
		  // database path, if it's new database, it will be created in the project folder
		  con = DriverManager.getConnection("jdbc:sqlite:data/courses.db");
		 initialise();
		 //initialise2();
		 
		 
		 
	 }
	 
	 private static void initialise() throws SQLException {
		 if( !hasData ) {
			 hasData = true;
			 // check for database table
			 Statement state = con.createStatement();
			 ResultSet res = state.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='user'");
			 if( !res.next()) {
				 
				 System.out.println("Building the User table with prepopulated values.");
				 // need to build the table
				  Statement state2 = con.createStatement();
				  state2.executeUpdate("create table user(id integer,"
				    + "courseName Varchar(30)," + "courseGoal  Varchar(20),"+ "date  Varchar(30),"+ "hours  int(5),"+ "instructor  Varchar(20),"
				    + "primary key (id));");

				
			 }
			 
		 }
	 }
	 
	 public static void insert(int id,  String courseName,String courseGoal,String date,int hours,String instructor) {
			
				if(con == null) {
					 // get connection
					 try {
						getConnection();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }
			try {
				Statement state = con.createStatement();
				state.executeUpdate("INSERT INTO user " + "VALUES ('"+id+"','"+courseName+"','"+courseGoal+"','"+date+"','"+hours+"','"+instructor+"')");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
	 
	 public static ArrayList<String> getItems() throws SQLException {
		 ArrayList<String> items= new ArrayList<String>();
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
		
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select courseName from user");
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount(); 

			while (rs.next()) {
			//Print one row          
			for(int i = 0 ; i < columnsNumber; i++){

			 items.add(rs.getString(1));

			}
			}
			
		return items;

		}

	 public static newCourse getCourseData(String name) throws SQLException {
		 newCourse course = null;
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
			ResultSet rsGoal = con.createStatement().executeQuery("select courseGoal from user where courseName ='"+name+"'");
			ResultSet rsDate = con.createStatement().executeQuery("select date from user where courseName ='"+name+"'");
			ResultSet rsHours = con.createStatement().executeQuery("select hours from user where courseName ='"+name+"'");
			ResultSet rsInstructor = con.createStatement().executeQuery("select instructor from user where courseName ='"+name+"'");
			
			course=new newCourse(name,rsGoal.getString(1),rsDate.getString(1),rsHours.getInt(1),rsInstructor.getString(1));
			

			return course;

		}
	
	 
	 
	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					newCourse frame = new newCourse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	

	/**
	 * Create the frame.
	 */
	public newCourse() {
		setTitle("New Course");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 619, 444);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCourseInformation = new JLabel("course information");
		lblCourseInformation.setHorizontalAlignment(SwingConstants.CENTER);
		lblCourseInformation.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCourseInformation.setBounds(178, 49, 210, 16);
		contentPane.add(lblCourseInformation);
		
		JLabel lblCourseName = new JLabel("course name");
		lblCourseName.setBounds(42, 144, 79, 14);
		contentPane.add(lblCourseName);
		
		courseName = new JTextField();
		courseName.setColumns(10);
		courseName.setBounds(123, 141, 86, 20);
		contentPane.add(courseName);
		
		JLabel lblCourseGoal = new JLabel("course goal");
		lblCourseGoal.setHorizontalAlignment(SwingConstants.CENTER);
		lblCourseGoal.setBounds(287, 144, 73, 14);
		contentPane.add(lblCourseGoal);
		
		courseGoal = new JTextField();
		courseGoal.setColumns(10);
		courseGoal.setBounds(359, 141, 86, 20);
		contentPane.add(courseGoal);
		
		JLabel lblDate = new JLabel("date");
		lblDate.setBounds(42, 184, 69, 14);
		contentPane.add(lblDate);
		
		date = new JTextField();
		date.setColumns(10);
		date.setBounds(111, 181, 114, 20);
		contentPane.add(date);
		
		JLabel lblHours = new JLabel("hours");
		lblHours.setHorizontalAlignment(SwingConstants.CENTER);
		lblHours.setBounds(287, 184, 73, 14);
		contentPane.add(lblHours);
		
		hours = new JTextField();
		hours.setColumns(10);
		hours.setBounds(359, 181, 86, 20);
		contentPane.add(hours);
		
		JLabel lblInstructor = new JLabel("instructor");
		lblInstructor.setHorizontalAlignment(SwingConstants.CENTER);
		lblInstructor.setBounds(118, 235, 73, 14);
		contentPane.add(lblInstructor);
		
		instructor = new JTextField();
		instructor.setColumns(10);
		instructor.setBounds(190, 232, 102, 20);
		contentPane.add(instructor);
		
		JButton btnAddCourse = new JButton("Add course");
		btnAddCourse.setBounds(485, 357, 108, 23);
		btnAddCourse.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Ids.idPartner++;
				insert(Ids.idPartner, courseName.getText(), courseGoal.getText(), date.getText(), Integer.parseInt(hours.getText()), instructor.getText());
				Ids.idPartner++;
				JOptionPane.showMessageDialog(null, "Course is added SuccessFully!");
			}
		});
		contentPane.add(btnAddCourse);
	}
	 public String getCourseNameString() {
		return courseNameString;
	}

	public void setCourseNameString(String courseNameString) {
		this.courseNameString = courseNameString;
	}

	public String getCourseGoalString() {
		return courseGoalString;
	}

	public void setCourseGoalString(String courseGoalString) {
		this.courseGoalString = courseGoalString;
	}

	public String getDateString() {
		return dateString;
	}

	public void setDateString(String dateString) {
		this.dateString = dateString;
	}

	public int getHoursInt() {
		return hoursInt;
	}

	public void setHoursInt(int hoursInt) {
		this.hoursInt = hoursInt;
	}

	public String getInstructorString() {
		return instructorString;
	}

	public void setInstructorString(String instructorString) {
		this.instructorString = instructorString;
	}
	

}
