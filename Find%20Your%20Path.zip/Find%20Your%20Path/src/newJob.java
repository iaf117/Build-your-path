import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;

public class newJob extends JFrame {

	private JPanel contentPane;
	private JTextField jobType;
	private JTextField location;
	private JTextField salary;
	private JTextField gender;

	private static Connection con;
	 private static boolean hasData = false;
	
	 private String typeString;
	 public newJob(String typeString, String locationString, double salaryDouble, String genderString, String jobDescString) {
		this.typeString = typeString;
		this.locationString = locationString;
		this.salaryDouble = salaryDouble;
		this.genderString = genderString;
		this.jobDescString = jobDescString;
	}

	public String getTypeString() {
		return typeString;
	}

	public void setTypeString(String typeString) {
		this.typeString = typeString;
	}

	public String getLocationString() {
		return locationString;
	}

	public void setLocationString(String locationString) {
		this.locationString = locationString;
	}

	public double getSalaryDouble() {
		return salaryDouble;
	}

	public void setSalaryDouble(double salaryDouble) {
		this.salaryDouble = salaryDouble;
	}

	public String getGenderString() {
		return genderString;
	}

	public void setGenderString(String genderString) {
		this.genderString = genderString;
	}

	public String getJobDescString() {
		return jobDescString;
	}

	public void setJobDescString(String jobDescString) {
		this.jobDescString = jobDescString;
	}


	private String locationString;
	 private double salaryDouble;
	 private String genderString;
	 private String jobDescString;
	 
	 
	 private static void getConnection() throws ClassNotFoundException, SQLException {
		  // sqlite driver
		  Class.forName("org.sqlite.JDBC");
		  // database path, if it's new database, it will be created in the project folder
		  con = DriverManager.getConnection("jdbc:sqlite:data/jobs.db");
		 initialise();
		 //initialise2();
		 
		 
		 
	 }
	 
	 private static void initialise() throws SQLException {
		 if( !hasData ) {
			 hasData = true;
			 // check for database table
			 Statement state = con.createStatement();
			 ResultSet res = state.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='user'");
			 if( !res.next()) {
				 
				 System.out.println("Building the User table with prepopulated values.");
				 // need to build the table
				  Statement state2 = con.createStatement();
				  state2.executeUpdate("create table user(id integer,"
				    + "jobType Varchar(30)," + "location  Varchar(20),"+ "salary  double(30),"+ "gender  Varchar(10),"+ "jobDesc  Varchar(100),"
				    + "primary key (id));");

				
			 }
			 
		 }
	 }
	 
	 public static void insert(int id, String jobType,String location,double salary,String gender,String jobDesc) {
			
				if(con == null) {
					 // get connection
					 try {
						getConnection();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }
			try {
				Statement state = con.createStatement();
				state.executeUpdate("INSERT INTO user " + "VALUES ('"+id+"','"+jobType+"','"+location+"','"+salary+"','"+gender+"','"+jobDesc+"')");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
	 
	 public static ArrayList<String> getItems() throws SQLException {
		 ArrayList<String> items= new ArrayList<String>();
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
		
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select jobType from user");
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount(); 

			while (rs.next()) {
			//Print one row          
			for(int i = 0 ; i < columnsNumber; i++){

			 items.add(rs.getString(1));

			}
			}
			
		return items;

		}

	
	 public static newJob getJobData(String name) throws SQLException {
		 newJob job = null;
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
			//jobType Varchar(30)," + "location  Varchar(20),"+ "salary  double(30),"+ "gender  Varchar(10),"+ "jobDesc  Varchar(100),"
			ResultSet rsLocation = con.createStatement().executeQuery("select location from user where jobType ='"+name+"'");
			ResultSet rsSalary = con.createStatement().executeQuery("select salary from user where jobType ='"+name+"'");
			ResultSet rsGender = con.createStatement().executeQuery("select gender from user where jobType ='"+name+"'");
			ResultSet rsJobDesc = con.createStatement().executeQuery("select jobDesc from user where jobType ='"+name+"'");
			
			job=new newJob(name,rsLocation.getString(1),rsSalary.getDouble(1),rsGender.getString(1),rsJobDesc.getString(1));
			

			return job;

		}
	
	 
	 
	
	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					newJob frame = new newJob();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public newJob() {
		setTitle("New Job");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 539, 419);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblJobInformation = new JLabel("job information");
		lblJobInformation.setHorizontalAlignment(SwingConstants.CENTER);
		lblJobInformation.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblJobInformation.setBounds(151, 34, 210, 16);
		contentPane.add(lblJobInformation);
		
		JLabel lblJobType = new JLabel("job type");
		lblJobType.setBounds(36, 94, 69, 14);
		contentPane.add(lblJobType);
		
		jobType = new JTextField();
		jobType.setColumns(10);
		jobType.setBounds(96, 91, 86, 20);
		contentPane.add(jobType);
		
		JLabel lblLocation = new JLabel("location");
		lblLocation.setHorizontalAlignment(SwingConstants.CENTER);
		lblLocation.setBounds(229, 94, 73, 14);
		contentPane.add(lblLocation);
		
		location = new JTextField();
		location.setColumns(10);
		location.setBounds(301, 91, 212, 20);
		contentPane.add(location);
		
		salary = new JTextField();
		salary.setColumns(10);
		salary.setBounds(301, 131, 86, 20);
		contentPane.add(salary);
		
		JLabel lblSalary = new JLabel("salary");
		lblSalary.setHorizontalAlignment(SwingConstants.CENTER);
		lblSalary.setBounds(229, 134, 73, 14);
		contentPane.add(lblSalary);
		
		gender = new JTextField();
		gender.setColumns(10);
		gender.setBounds(96, 131, 114, 20);
		contentPane.add(gender);
		
		JLabel lblGender = new JLabel("gender");
		lblGender.setBounds(36, 134, 61, 14);
		contentPane.add(lblGender);
		
		JLabel lblNewLabel_1 = new JLabel("job Describtion");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(26, 176, 122, 14);
		contentPane.add(lblNewLabel_1);
		
		JTextArea jobDesc = new JTextArea();
		jobDesc.setBounds(158, 176, 203, 138);
		contentPane.add(jobDesc);
		
		JButton btnAddJob = new JButton("Add job");
		btnAddJob.setBounds(405, 346, 108, 23);
		btnAddJob.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				insert(Ids.idUser, jobType.getText(), location.getText(), Double.parseDouble(salary.getText()), gender.getText(), jobDesc.getText());
				Ids.idUser++;
				JOptionPane.showMessageDialog(null, "Job is Added Successfully!");
			}
		});
		contentPane.add(btnAddJob);
	}

}
