import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import javax.swing.JButton;

public class newOffer extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					newOffer frame = new newOffer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public newOffer() {
		setTitle("New Offer (For Partner)");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 412, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddNewOffer = new JLabel("Add new offer");
		lblAddNewOffer.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddNewOffer.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAddNewOffer.setBounds(86, 41, 210, 16);
		contentPane.add(lblAddNewOffer);
		
		JButton btn_course = new JButton("course");
		btn_course.setBounds(147, 84, 103, 23);
		btn_course.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				newCourse.run();
			}
		});
		contentPane.add(btn_course);
		
		JButton btn_job = new JButton("job");
		btn_job.setBounds(147, 118, 103, 23);
		btn_job.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				newJob.run();
			}
		});
		contentPane.add(btn_job);
		
		JButton btn_volunteer = new JButton("volunteer ");
		btn_volunteer.setBounds(147, 152, 103, 23);
		btn_volunteer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				newVoulnteer.run();
			}
		});
		contentPane.add(btn_volunteer);
		
		JButton btnShowRegisteredUsers = new JButton("show registered users ");
		btnShowRegisteredUsers.setBounds(110, 217, 168, 23);
		btnShowRegisteredUsers.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				registeredUsers.run();
				
			}
		});
		contentPane.add(btnShowRegisteredUsers);
		
		JLabel lblNewLabel = new JLabel("or");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(57, 221, 46, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("log out");
		btnNewButton.setBounds(297, 297, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Home.main(null);
				dispose();
			}
		});
		contentPane.add(btnNewButton);
	}

}
