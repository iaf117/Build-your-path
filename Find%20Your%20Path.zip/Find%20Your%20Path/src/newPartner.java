import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class newPartner extends JFrame {

	private JPanel contentPane;
	private JTextField companyName;
	private JTextField phone;
	private JTextField city;
	private JTextField country;
	private JTextField email;
	private JTextField website;
	private JTextField pass;
	private JTextField confirmPass;

	
	private static Connection con;
	 private static boolean hasData = false;
	
	 
	 private static void getConnection() throws ClassNotFoundException, SQLException {
		  // sqlite driver
		  Class.forName("org.sqlite.JDBC");
		  // database path, if it's new database, it will be created in the project folder
		  con = DriverManager.getConnection("jdbc:sqlite:data/Company.db");
		 initialise();
		 //initialise2();
		 
		 
		 
	 }
	 
	 private static void initialise() throws SQLException {
		 if( !hasData ) {
			 hasData = true;
			 // check for database table
			 Statement state = con.createStatement();
			 ResultSet res = state.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='user'");
			 if( !res.next()) {
				 
				 System.out.println("Building the User table with prepopulated values.");
				 // need to build the table
				  Statement state2 = con.createStatement();
				  state2.executeUpdate("create table user(id integer,"
				    + "companyName Varchar(50)," + "phone  Varchar(40),"+ "city Varchar(20),"+ "country  Varchar(20),"+ "email  Varchar(20),"
				    + "website  Varchar(20),"+ "sectorType  int(20),"+ "companyType Varchar(30),"+ "companyDesc Varchar(30),"
				    + "password Varchar(30),"+ "primary key (id));");

				
			 }
			 
		 }
	 }
	 
	 public static void insert(int id, String companyName,String phone,String city,String country,String email,String website,
			String sectorType,String companyType,String companyDesc,String password) {
			// create a Statement from the connection
				
				if(con == null) {
					 // get connection
					 try {
						getConnection();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }
			try {
				Statement state = con.createStatement();
				state.executeUpdate("INSERT INTO user " + "VALUES ('"+id+"','"+companyName+"','"+phone+"','"+city+"','"+country+"','"+email+"','"+website+"','"+sectorType+"','"
						+companyType+"','"+companyDesc+"','"+password+"')");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
	 
	 public static boolean verify(String name, String pass) throws SQLException {
		 boolean result=false;
		 if(con == null) {
			 // get connection
			 try {
				getConnection();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 ResultSet rs = null;
		 ResultSet rs2 = null;
		try {
			 rs = con.createStatement().executeQuery("select companyName from user where companyName ='"+name+"'");
			 rs2 = con.createStatement().executeQuery("select password from user where companyName ='"+name+"'");
		} catch (Exception e) {
			
		} 
		
		if (rs.getString(1).equals(name)&& rs2.getString(1).equals(pass)) {
			result=true;
		}
       
   return result;
		}
	
	 
	
	
	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					newPartner frame = new newPartner();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		
	/**
	 * Create the frame.
	 */
	public newPartner() {
		setTitle("New Partner");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 799, 520);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCreateNewPartner = new JLabel("create new partner");
		lblCreateNewPartner.setBounds(0, 24, 773, 16);
		lblCreateNewPartner.setHorizontalAlignment(SwingConstants.CENTER);
		lblCreateNewPartner.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblCreateNewPartner);
		
		JLabel lblNewLabel = new JLabel("company Name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(143, 83, 97, 14);
		contentPane.add(lblNewLabel);
		
		companyName = new JTextField();
		companyName.setBounds(239, 80, 86, 20);
		contentPane.add(companyName);
		companyName.setColumns(10);
		
		JLabel lblPhone = new JLabel("phone");
		lblPhone.setHorizontalAlignment(SwingConstants.CENTER);
		lblPhone.setBounds(398, 83, 51, 14);
		contentPane.add(lblPhone);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(448, 80, 86, 20);
		contentPane.add(phone);
		
		JLabel lblCity = new JLabel("city");
		lblCity.setHorizontalAlignment(SwingConstants.CENTER);
		lblCity.setBounds(176, 111, 51, 14);
		contentPane.add(lblCity);
		
		city = new JTextField();
		city.setColumns(10);
		city.setBounds(224, 108, 58, 20);
		contentPane.add(city);
		
		JLabel lblCountry = new JLabel("country");
		lblCountry.setHorizontalAlignment(SwingConstants.CENTER);
		lblCountry.setBounds(325, 111, 51, 14);
		contentPane.add(lblCountry);
		
		country = new JTextField();
		country.setColumns(10);
		country.setBounds(375, 108, 86, 20);
		contentPane.add(country);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail.setBounds(133, 154, 51, 14);
		contentPane.add(lblEmail);
		
		email = new JTextField();
		email.setColumns(10);
		email.setBounds(183, 151, 229, 20);
		contentPane.add(email);
		
		JLabel lblCountry_1_1 = new JLabel("website");
		lblCountry_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblCountry_1_1.setBounds(422, 154, 51, 14);
		contentPane.add(lblCountry_1_1);
		
		website = new JTextField();
		website.setColumns(10);
		website.setBounds(472, 151, 166, 20);
		contentPane.add(website);
		
		JLabel lblEmail_1 = new JLabel("sector type");
		lblEmail_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail_1.setBounds(143, 193, 69, 14);
		contentPane.add(lblEmail_1);
		
		JRadioButton rPublic = new JRadioButton("public");
		rPublic.setBounds(218, 189, 63, 23);
		contentPane.add(rPublic);
		
		JRadioButton rPrivate = new JRadioButton("private");
		rPrivate.setBounds(284, 189, 69, 23);
		contentPane.add(rPrivate);
		
		ButtonGroup bGroup=new ButtonGroup();
		bGroup.add(rPrivate);
		bGroup.add(rPublic);
		
		
		
		JLabel lblEmail_1_1 = new JLabel("company type");
		lblEmail_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail_1_1.setBounds(387, 193, 80, 14);
		contentPane.add(lblEmail_1_1);
		
		JRadioButton rLocal = new JRadioButton("local");
		rLocal.setBounds(473, 189, 63, 23);
		contentPane.add(rLocal);
		
		JRadioButton rInternational = new JRadioButton("International");
		rInternational.setBounds(539, 189, 99, 23);
		contentPane.add(rInternational);
		
		ButtonGroup bGroup2=new ButtonGroup();
		bGroup2.add(rInternational);
		bGroup2.add(rLocal);
		
		JLabel lblNewLabel_1 = new JLabel("company Describtion");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(152, 241, 122, 14);
		contentPane.add(lblNewLabel_1);
		
		JTextArea companyDesc = new JTextArea();
		companyDesc.setBounds(284, 241, 203, 138);
		contentPane.add(companyDesc);
		
		JLabel lblCountry_1_1_1 = new JLabel("password");
		lblCountry_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblCountry_1_1_1.setBounds(119, 401, 69, 14);
		contentPane.add(lblCountry_1_1_1);
		
		pass = new JTextField();
		pass.setColumns(10);
		pass.setBounds(187, 398, 166, 20);
		contentPane.add(pass);
		
		JLabel lblCountry_1_1_2 = new JLabel("confirm password");
		lblCountry_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblCountry_1_1_2.setBounds(387, 401, 110, 14);
		contentPane.add(lblCountry_1_1_2);
		
		confirmPass = new JTextField();
		confirmPass.setColumns(10);
		confirmPass.setBounds(496, 398, 166, 20);
		contentPane.add(confirmPass);
		
		JButton btn_signup = new JButton("sign up");
		btn_signup.setBounds(684, 447, 89, 23);
		btn_signup.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String sectorType="";
				String companyType="";
				if (rPrivate.isSelected()) {
					sectorType="private";
				}
				else {
					sectorType="public";
				}
				
				if (rLocal.isSelected()) {
					companyType="local";
				}
				else {
					companyType="International";
				}
				
				if (pass.getText().equals(confirmPass.getText())) {
					insert(Ids.idPartner, companyName.getText(), phone.getText(), city.getText(), country.getText(),
							email.getText(), website.getText(), sectorType, companyType, companyDesc.getText(), pass.getText());
					Ids.idPartner++;
					newOffer.run();
					dispose();
				}
				else {
					JOptionPane.showMessageDialog(null, "Passwords don't match!");
				}
				
			}
		});
		contentPane.add(btn_signup);
	}
}
