import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

public class newUser extends JFrame {

	private JPanel contentPane;
	private JTextField fname;
	private JTextField mname;
	private JTextField lname;
	private JTextField email;
	private JTextField city;
	private JTextField country;
	private JTextField age;
	private JTextField phone;
	private JTextField education;
	private JTextField workExperience;
	private JTextField skills;
	private JTextField pass;
	private JTextField confirmPass;
	
	
	
	private static Connection con;
	 private static boolean hasData = false;
	
	 
	 private static void getConnection() throws ClassNotFoundException, SQLException {
		  // sqlite driver
		  Class.forName("org.sqlite.JDBC");
		  // database path, if it's new database, it will be created in the project folder
		  con = DriverManager.getConnection("jdbc:sqlite:data/users.db");
		 initialise();
		 //initialise2();
		 
		 
		 
	 }
	 
	 private static void initialise() throws SQLException {
		 if( !hasData ) {
			 hasData = true;
			 // check for database table
			 Statement state = con.createStatement();
			 ResultSet res = state.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='user'");
			 if( !res.next()) {
				 
				 System.out.println("Building the User table with prepopulated values.");
				 // need to build the table
				  Statement state2 = con.createStatement();
				  state2.executeUpdate("create table user(id integer,"
				    + "fName Varchar(10)," + "mName  Varchar(20),"+ "lName  Varchar(20),"+ "email  Varchar(20),"+ "city  Varchar(20),"
				    + "country  Varchar(20),"+ "age  int(20),"+ "phone Varchar(30),"+ "education Varchar(30),"+ "workExp Varchar(30),"+ "skills Varchar(30),"
				    + "password Varchar(30),"+ "primary key (id));");

				
			 }
			 
		 }
	 }
	 
	 public static void insert(int id,  String fname,String mname,String lname,String email,String city,String country,
			 int age,String phone,String education,String workExp,String skills , String password) {
			// create a Statement from the connection
				
				if(con == null) {
					 // get connection
					 try {
						getConnection();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }
			try {
				Statement state = con.createStatement();
				state.executeUpdate("INSERT INTO user " + "VALUES ('"+id+"','"+fname+"','"+mname+"','"+lname+"','"+email+"','"+city+"','"+country+"','"+age+"','"
						+phone+"','"+education+"','"+workExp+"','"+skills+"','"+password+"')");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
	 
	 public static void delete(String email) {
			// create a Statement from the connection
				
				if(con == null) {
					 // get connection
					 try {
						getConnection();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }
			try {
				Statement state = con.createStatement();
				state.executeUpdate("Delete from user where email ='"+email+"'");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
	
	 public static boolean verify(String email, String pass) throws SQLException {
		 boolean result=false;
		 if(con == null) {
			 // get connection
			 try {
				getConnection();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 ResultSet rs = null;
		 ResultSet rs2 = null;
		try {
			 rs = con.createStatement().executeQuery("select email from user where email ='"+email+"'");
			 rs2 = con.createStatement().executeQuery("select password from user where email ='"+email+"'");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "User doesn't exist!");
		} 
		
		if (rs.getString(1).equals(email)&& rs2.getString(1).equals(pass)) {
			result=true;
		}
       
   return result;
		}
	 
	 public static ArrayList<String> getItems() throws SQLException {
		 ArrayList<String> items= new ArrayList<String>();
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
		
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select email from user");
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount(); 

			while (rs.next()) {
			//Print one row          
			for(int i = 0 ; i < columnsNumber; i++){

			 items.add(rs.getString(1));

			}
			}
			
		return items;

		}
	 

	 public static newUser getUserData(String email) throws SQLException {
		 newUser user = null;
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
			
			
			ResultSet rsFname = con.createStatement().executeQuery("select fname from user where email ='"+email+"'");
			ResultSet rsMname = con.createStatement().executeQuery("select mName from user where email ='"+email+"'");
			ResultSet rsLname = con.createStatement().executeQuery("select lName from user where email ='"+email+"'");
			ResultSet rsCity = con.createStatement().executeQuery("select city from user where email ='"+email+"'");
			ResultSet rsCountry = con.createStatement().executeQuery("select country from user where email ='"+email+"'");
			ResultSet rsAge = con.createStatement().executeQuery("select age from user where email ='"+email+"'");
			ResultSet rsPhone = con.createStatement().executeQuery("select phone from user where email ='"+email+"'");
			ResultSet rsEducation = con.createStatement().executeQuery("select education from user where email ='"+email+"'");
			ResultSet rsWorkExp = con.createStatement().executeQuery("select workExp from user where email ='"+email+"'");
			ResultSet rsskills = con.createStatement().executeQuery("select skills from user where email ='"+email+"'");
			
			user=new newUser(rsFname.getString(1), rsMname.getString(1), rsLname.getString(1), email, rsCity.getString(1), rsCountry.getString(1),
					rsAge.getInt(1),
					rsPhone.getString(1), rsEducation.getString(1), rsWorkExp.getString(1),
					rsskills.getString(1));
			

			return user;

		}
	 
	 
	 
	 
	 
	 
	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					newUser frame = new newUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public newUser() {
		setTitle("New User");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 809, 487);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblVoulnteerInformation = new JLabel("create new user");
		lblVoulnteerInformation.setHorizontalAlignment(SwingConstants.CENTER);
		lblVoulnteerInformation.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblVoulnteerInformation.setBounds(10, 25, 773, 16);
		contentPane.add(lblVoulnteerInformation);
		
		JLabel lblFirstName = new JLabel("First name");
		lblFirstName.setHorizontalAlignment(SwingConstants.CENTER);
		lblFirstName.setBounds(94, 84, 97, 14);
		contentPane.add(lblFirstName);
		
		fname = new JTextField();
		fname.setColumns(10);
		fname.setBounds(190, 81, 97, 20);
		contentPane.add(fname);
		
		JLabel lblMiddleName = new JLabel("Middle name");
		lblMiddleName.setHorizontalAlignment(SwingConstants.CENTER);
		lblMiddleName.setBounds(320, 84, 84, 14);
		contentPane.add(lblMiddleName);
		
		mname = new JTextField();
		mname.setColumns(10);
		mname.setBounds(414, 81, 97, 20);
		contentPane.add(mname);
		
		JLabel lblLastName = new JLabel("Last name");
		lblLastName.setHorizontalAlignment(SwingConstants.CENTER);
		lblLastName.setBounds(545, 84, 62, 14);
		contentPane.add(lblLastName);
		
		lname = new JTextField();
		lname.setColumns(10);
		lname.setBounds(619, 81, 97, 20);
		contentPane.add(lname);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail.setBounds(122, 127, 97, 14);
		contentPane.add(lblEmail);
		
		email = new JTextField();
		email.setColumns(10);
		email.setBounds(218, 124, 374, 20);
		contentPane.add(email);
		
		JLabel lblCity = new JLabel("city");
		lblCity.setHorizontalAlignment(SwingConstants.CENTER);
		lblCity.setBounds(140, 174, 51, 14);
		contentPane.add(lblCity);
		
		city = new JTextField();
		city.setColumns(10);
		city.setBounds(188, 171, 76, 20);
		contentPane.add(city);
		
		JLabel lblCountry = new JLabel("country");
		lblCountry.setHorizontalAlignment(SwingConstants.CENTER);
		lblCountry.setBounds(289, 174, 51, 14);
		contentPane.add(lblCountry);
		
		country = new JTextField();
		country.setColumns(10);
		country.setBounds(339, 171, 86, 20);
		contentPane.add(country);
		
		JLabel lblAge = new JLabel("age");
		lblAge.setHorizontalAlignment(SwingConstants.CENTER);
		lblAge.setBounds(140, 216, 51, 14);
		contentPane.add(lblAge);
		
		age = new JTextField();
		age.setColumns(10);
		age.setBounds(188, 213, 76, 20);
		contentPane.add(age);
		
		JLabel lblPhone = new JLabel("phone");
		lblPhone.setHorizontalAlignment(SwingConstants.CENTER);
		lblPhone.setBounds(289, 216, 51, 14);
		contentPane.add(lblPhone);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(339, 213, 86, 20);
		contentPane.add(phone);
		
		JLabel lblEducation = new JLabel("education");
		lblEducation.setHorizontalAlignment(SwingConstants.CENTER);
		lblEducation.setBounds(104, 258, 97, 14);
		contentPane.add(lblEducation);
		
		education = new JTextField();
		education.setColumns(10);
		education.setBounds(200, 255, 120, 20);
		contentPane.add(education);
		
		JLabel lblWorkExperience = new JLabel("work experience");
		lblWorkExperience.setHorizontalAlignment(SwingConstants.CENTER);
		lblWorkExperience.setBounds(339, 258, 103, 14);
		contentPane.add(lblWorkExperience);
		
		workExperience = new JTextField();
		workExperience.setColumns(10);
		workExperience.setBounds(449, 255, 114, 20);
		contentPane.add(workExperience);
		
		JLabel lblskills_1 = new JLabel("skills");
		lblskills_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblskills_1.setBounds(566, 258, 51, 14);
		contentPane.add(lblskills_1);
		
		skills = new JTextField();
		skills.setColumns(10);
		skills.setBounds(616, 255, 124, 20);
		contentPane.add(skills);
		
		JLabel lblCountry_1_1_1 = new JLabel("password");
		lblCountry_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblCountry_1_1_1.setBounds(111, 368, 69, 14);
		contentPane.add(lblCountry_1_1_1);
		
		pass = new JTextField();
		pass.setColumns(10);
		pass.setBounds(179, 365, 166, 20);
		contentPane.add(pass);
		
		JLabel lblCountry_1_1_2 = new JLabel("confirm password");
		lblCountry_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblCountry_1_1_2.setBounds(379, 368, 110, 14);
		contentPane.add(lblCountry_1_1_2);
		
		confirmPass = new JTextField();
		confirmPass.setColumns(10);
		confirmPass.setBounds(488, 365, 166, 20);
		contentPane.add(confirmPass);
		
		JButton btn_signup = new JButton("sign up");
		btn_signup.setBounds(682, 414, 89, 23);
		btn_signup.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (pass.getText().equals(confirmPass.getText())) {
					Ids.idUser++;
					insert(Ids.idUser, fname.getText(), mname.getText(), lname.getText(), email.getText(), city.getText(),
							country.getText(), Integer.parseInt(age.getText()), phone.getText(), education.getText(), workExperience.getText(), skills.getText(), pass.getText());
					Ids.idUser++;
					newApply.run();
					dispose();
					Home.username=email.getText();
				}
				else {
					JOptionPane.showMessageDialog(null, "Passwords don't match!");
				}
				
			}
		});
		contentPane.add(btn_signup);
	}
	
	
	private String fnameString;
	private String mnameString;
	private String lnameString;
	private String emailString;
	private String cityString;
	private String countryString;
	private int ageInt;
	private String phoneString;
	private String educationString;
	private String workExpString;
	
	public newUser(String fnameString, String mnameString, String lnameString, String emailString, String cityString,
			String countryString, int ageInt, String phoneString, String educationString, String workExpString,
			String skillsString) throws HeadlessException {
		super();
		this.fnameString = fnameString;
		this.mnameString = mnameString;
		this.lnameString = lnameString;
		this.emailString = emailString;
		this.cityString = cityString;
		this.countryString = countryString;
		this.ageInt = ageInt;
		this.phoneString = phoneString;
		this.educationString = educationString;
		this.workExpString = workExpString;
		this.skillsString = skillsString;
	}
	public String getFnameString() {
		return fnameString;
	}

	public void setFnameString(String fnameString) {
		this.fnameString = fnameString;
	}

	public String getMnameString() {
		return mnameString;
	}

	public void setMnameString(String mnameString) {
		this.mnameString = mnameString;
	}

	public String getLnameString() {
		return lnameString;
	}

	public void setLnameString(String lnameString) {
		this.lnameString = lnameString;
	}

	public String getEmailString() {
		return emailString;
	}

	public void setEmailString(String emailString) {
		this.emailString = emailString;
	}

	public String getCityString() {
		return cityString;
	}

	public void setCityString(String cityString) {
		this.cityString = cityString;
	}

	public String getCountryString() {
		return countryString;
	}

	public void setCountryString(String countryString) {
		this.countryString = countryString;
	}

	public String getEducationString() {
		return educationString;
	}

	public void setEducationString(String educationString) {
		this.educationString = educationString;
	}

	public String getskillsString() {
		return skillsString;
	}

	public void setskillsString(String skillsString) {
		this.skillsString = skillsString;
	}
	
	public int getAgeInt() {
		return ageInt;
	}

	public void setAgeInt(int ageInt) {
		this.ageInt = ageInt;
	}

	public String getPhoneString() {
		return phoneString;
	}

	public void setPhoneString(String phoneString) {
		this.phoneString = phoneString;
	}

	public String getWorkExpString() {
		return workExpString;
	}

	public void setWorkExpString(String workExpString) {
		this.workExpString = workExpString;
	}

	private String skillsString;
	
	
	
	
}
