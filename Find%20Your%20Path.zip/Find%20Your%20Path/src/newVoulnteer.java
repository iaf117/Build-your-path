import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

public class newVoulnteer extends JFrame {

	private JPanel contentPane;
	private JTextField detail;
	private JTextField tasks;
	private JTextField date;
	private JTextField seatNumber;
	private JTextField place;
	private JTextField city;
	private JTextField qualfication;
	private JTextField enrollment;
	private JTextField supportProvided;
	private JTextField requiredAge;
	
	private String taskString;
	private String dateString;
	private String seatNumberString;
	private String placeString;
	private String cityString;
	private String qualificationString;
	private String enrollmentString;
	private String supportProvidedString;
	private String isRemoteString;
	private String isUrgentString;
	private String interviewString;
	

	private String genderString;
	private int requiredAgeInt;

	
	private String detailString;
	
	
	


	private static Connection con;
	 private static boolean hasData = false;
	
	 
	 private static void getConnection() throws ClassNotFoundException, SQLException {
		  // sqlite driver
		  Class.forName("org.sqlite.JDBC");
		  // database path, if it's new database, it will be created in the project folder
		  con = DriverManager.getConnection("jdbc:sqlite:data/Volunteers.db");
		 initialise();
		 //initialise2();
		 
		 
		 
	 }
	 
	 private static void initialise() throws SQLException {
		 if( !hasData ) {
			 hasData = true;
			 // check for database table
			 Statement state = con.createStatement();
			 ResultSet res = state.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='user'");
			 if( !res.next()) {
				 
				 System.out.println("Building the User table with prepopulated values.");
				 // need to build the table
				  Statement state2 = con.createStatement();
				  state2.executeUpdate("create table user(id integer,"
				    + "detail Varchar(50)," + "tasks  Varchar(40),"+ "date Varchar(20),"+ "seatNumber  Varchar(20),"+ "place  Varchar(20),"
				    + "city  Varchar(20),"+ "qualfication  int(20),"+ "enrollment Varchar(30),"+ "supportProvided Varchar(30),"
				    + "isRemote int(5)," + "isUrgent Varchar(5)," + "requiresInterview Varchar(5)," + "gender Varchar(5),"+ "requiredAge Varchar(5),"+ "primary key (id));");

				
			 }
			 
		 }
	 }
	 
	 public static void insert(int id, String detail,String tasks,String date,String seatNumber,String place,String city,
			String qualfication,String enrollment,String supportProvided,String isRemote,String isUrgent,String requiresInterview,String gender,int requiredAge) {
			// create a Statement from the connection
				
				if(con == null) {
					 // get connection
					 try {
						getConnection();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }
			try {
				Statement state = con.createStatement();
				state.executeUpdate("INSERT INTO user " + "VALUES ('"+id+"','"+detail+"','"+tasks+"','"+date+"','"+seatNumber+"','"+place+"','"+city+"','"+qualfication+"','"
						+enrollment+"','"+supportProvided+"','"+isRemote+"','"+isUrgent+"','"+requiresInterview+"','"+gender+"','"+requiredAge+"')");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
	 
	 public static ArrayList<String> getItems() throws SQLException {
		 ArrayList<String> items= new ArrayList<String>();
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
		
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select detail from user");
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount(); 

			while (rs.next()) {
			//Print one row          
			for(int i = 0 ; i < columnsNumber; i++){

			 items.add(rs.getString(1));

			}
			}
			
		return items;

		}
	 
	 
	 
	 public static newVoulnteer getVoulnteerData(String name) throws SQLException {
		 newVoulnteer volunteer = null;
			if(con == null) {
				 // get connection
				 try {
					getConnection();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }
			
			
			ResultSet rsTasks = con.createStatement().executeQuery("select tasks from user where detail ='"+name+"'");
			ResultSet rsDate = con.createStatement().executeQuery("select date from user where detail ='"+name+"'");
			ResultSet rsSeatNumber = con.createStatement().executeQuery("select seatNumber from user where detail ='"+name+"'");
			ResultSet rsPlace = con.createStatement().executeQuery("select place from user where detail ='"+name+"'");
			ResultSet rsCity = con.createStatement().executeQuery("select city from user where detail ='"+name+"'");
			ResultSet rsQualification = con.createStatement().executeQuery("select qualfication from user where detail ='"+name+"'");
			ResultSet rsEnrollment = con.createStatement().executeQuery("select enrollment from user where detail ='"+name+"'");
			ResultSet rsSupport = con.createStatement().executeQuery("select supportProvided from user where detail ='"+name+"'");
			ResultSet rsRemote = con.createStatement().executeQuery("select isRemote from user where detail ='"+name+"'");
			ResultSet rsUrgent = con.createStatement().executeQuery("select isUrgent from user where detail ='"+name+"'");
			ResultSet rsInterview = con.createStatement().executeQuery("select requiresInterview from user where detail ='"+name+"'");
			ResultSet rsGender = con.createStatement().executeQuery("select gender from user where detail ='"+name+"'");
			ResultSet rsAge = con.createStatement().executeQuery("select requiredAge from user where detail ='"+name+"'");
			
			volunteer=new newVoulnteer(name, rsTasks.getString(1), rsDate.getString(1), rsCity.getString(1), rsPlace.getString(1), rsSeatNumber.getString(1),
					rsQualification.getString(1), rsEnrollment.getString(1), rsSupport.getString(1),
					rsRemote.getString(1), rsUrgent.getString(1), rsInterview.getString(1), rsGender.getString(1), rsAge.getInt(1));
			

			return volunteer;

		}
	

	
	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					newVoulnteer frame = new newVoulnteer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public newVoulnteer() {
		setTitle("New Volunteer");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 797, 447);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblVoulnteerInformation = new JLabel("volunteer information");
		lblVoulnteerInformation.setHorizontalAlignment(SwingConstants.CENTER);
		lblVoulnteerInformation.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblVoulnteerInformation.setBounds(0, 22, 773, 16);
		contentPane.add(lblVoulnteerInformation);
		
		JLabel lblVoulnteerDetail = new JLabel("voulnteer detail");
		lblVoulnteerDetail.setHorizontalAlignment(SwingConstants.CENTER);
		lblVoulnteerDetail.setBounds(84, 81, 97, 14);
		contentPane.add(lblVoulnteerDetail);
		
		detail = new JTextField();
		detail.setColumns(10);
		detail.setBounds(180, 78, 120, 20);
		contentPane.add(detail);
		
		JLabel lblTasks = new JLabel("tasks");
		lblTasks.setHorizontalAlignment(SwingConstants.CENTER);
		lblTasks.setBounds(327, 81, 51, 14);
		contentPane.add(lblTasks);
		
		tasks = new JTextField();
		tasks.setColumns(10);
		tasks.setBounds(377, 78, 114, 20);
		contentPane.add(tasks);
		
		JLabel lblDate = new JLabel("date");
		lblDate.setHorizontalAlignment(SwingConstants.CENTER);
		lblDate.setBounds(546, 81, 51, 14);
		contentPane.add(lblDate);
		
		date = new JTextField();
		date.setColumns(10);
		date.setBounds(596, 78, 124, 20);
		contentPane.add(date);
		
		JLabel lblCity = new JLabel("city");
		lblCity.setHorizontalAlignment(SwingConstants.CENTER);
		lblCity.setBounds(84, 128, 51, 14);
		contentPane.add(lblCity);
		
		JLabel lblPlace = new JLabel("place");
		lblPlace.setHorizontalAlignment(SwingConstants.CENTER);
		lblPlace.setBounds(277, 128, 51, 14);
		contentPane.add(lblPlace);
		
		JLabel lblSeatNumber = new JLabel("seat number");
		lblSeatNumber.setHorizontalAlignment(SwingConstants.CENTER);
		lblSeatNumber.setBounds(472, 128, 80, 14);
		contentPane.add(lblSeatNumber);
		
		seatNumber = new JTextField();
		seatNumber.setColumns(10);
		seatNumber.setBounds(553, 125, 124, 20);
		contentPane.add(seatNumber);
		
		place = new JTextField();
		place.setColumns(10);
		place.setBounds(327, 125, 97, 20);
		contentPane.add(place);
		
		city = new JTextField();
		city.setColumns(10);
		city.setBounds(134, 125, 80, 20);
		contentPane.add(city);
		
		JLabel lblQualfication = new JLabel("qualfication");
		lblQualfication.setHorizontalAlignment(SwingConstants.CENTER);
		lblQualfication.setBounds(63, 168, 72, 14);
		contentPane.add(lblQualfication);
		
		qualfication = new JTextField();
		qualfication.setColumns(10);
		qualfication.setBounds(134, 165, 80, 20);
		contentPane.add(qualfication);
		
		JLabel lblEnrollment = new JLabel("enrollment");
		lblEnrollment.setHorizontalAlignment(SwingConstants.CENTER);
		lblEnrollment.setBounds(265, 168, 63, 14);
		contentPane.add(lblEnrollment);
		
		enrollment = new JTextField();
		enrollment.setColumns(10);
		enrollment.setBounds(337, 165, 97, 20);
		contentPane.add(enrollment);
		
		JLabel lblSupportProvided = new JLabel("support provided");
		lblSupportProvided.setHorizontalAlignment(SwingConstants.CENTER);
		lblSupportProvided.setBounds(472, 168, 97, 14);
		contentPane.add(lblSupportProvided);
		
		supportProvided = new JTextField();
		supportProvided.setColumns(10);
		supportProvided.setBounds(575, 165, 124, 20);
		contentPane.add(supportProvided);
		
		JLabel lblIsRemote = new JLabel("is remote?");
		lblIsRemote.setHorizontalAlignment(SwingConstants.CENTER);
		lblIsRemote.setBounds(93, 214, 72, 14);
		contentPane.add(lblIsRemote);
		
		JComboBox isRemote = new JComboBox();
		isRemote.setModel(new DefaultComboBoxModel(new String[] {"yes", "no"}));
		isRemote.setBounds(163, 210, 51, 22);
		contentPane.add(isRemote);
		
		JLabel lblIsRemote_1 = new JLabel("urgent?");
		lblIsRemote_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblIsRemote_1.setBounds(265, 214, 72, 14);
		contentPane.add(lblIsRemote_1);
		
		JComboBox isUrgent = new JComboBox();
		isUrgent.setModel(new DefaultComboBoxModel(new String[] {"yes", "no"}));
		isUrgent.setBounds(335, 210, 51, 22);
		contentPane.add(isUrgent);
		
		JLabel lblIsRemote_2 = new JLabel("requires interview?");
		lblIsRemote_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblIsRemote_2.setBounds(412, 218, 114, 14);
		contentPane.add(lblIsRemote_2);
		
		JComboBox isRequireInterview = new JComboBox();
		isRequireInterview.setModel(new DefaultComboBoxModel(new String[] {"yes", "no"}));
		isRequireInterview.setBounds(528, 214, 51, 22);
		contentPane.add(isRequireInterview);
		
		JLabel lblIsRemote_3 = new JLabel("gender");
		lblIsRemote_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblIsRemote_3.setBounds(63, 264, 72, 14);
		contentPane.add(lblIsRemote_3);
		
		JComboBox gender = new JComboBox();
		gender.setModel(new DefaultComboBoxModel(new String[] {"Female", "Male"}));
		gender.setBounds(133, 260, 81, 22);
		contentPane.add(gender);
		
		JLabel lblRequiredAge = new JLabel("required age");
		lblRequiredAge.setHorizontalAlignment(SwingConstants.CENTER);
		lblRequiredAge.setBounds(256, 263, 72, 14);
		contentPane.add(lblRequiredAge);
		
		requiredAge = new JTextField();
		requiredAge.setColumns(10);
		requiredAge.setBounds(337, 260, 97, 20);
		contentPane.add(requiredAge);
		
		JButton btnAddVolunteer = new JButton("Add volunteer");
		btnAddVolunteer.setBounds(630, 353, 120, 23);
		btnAddVolunteer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String isRomoteString="Remote";
				String isUrgentString="Urgent";
				String genderString="Female";
				String requiresInterviewString="requiresInterview";
				
				if (isRemote.getSelectedIndex()==1) {
					isRomoteString="No";
				}
				if (isUrgent.getSelectedIndex()==1) {
					isUrgentString="NO";
				}
				if (gender.getSelectedIndex()==1) {
					genderString="Male";
				}
				if (isRequireInterview.getSelectedIndex()==1) {
					isRomoteString="No";
				}
				
				insert(Ids.idPartner, detail.getText(), tasks.getText(), date.getText(), seatNumber.getText(), place.getText(), city.getText(), qualfication.getText(),
						enrollment.getText(),
						supportProvided.getText(), isRomoteString, isUrgentString, requiresInterviewString, genderString, Integer.parseInt(requiredAge.getText()));
				Ids.idPartner++;
				JOptionPane.showMessageDialog(null, "Volunteer is Added Successfully!");
			}
		});
		contentPane.add(btnAddVolunteer);
	}
	
	
	
	
	public newVoulnteer(String detailString, String taskString, String dateString, String cityString,
			String placeString, String seatNumberString, String qualificationString, String enrollmentString,
			String supportProvidedString, String isRemoteString, String isUrgentString, String interviewString, String genderString, int requiredAgeInt
			) throws HeadlessException {
		super();
		this.detailString=detailString;
		this.taskString = taskString;
		this.dateString = dateString;
		this.seatNumberString = seatNumberString;
		this.placeString = placeString;
		this.cityString = cityString;
		this.qualificationString = qualificationString;
		this.enrollmentString = enrollmentString;
		this.supportProvidedString = supportProvidedString;
		this.isRemoteString = isRemoteString;
		this.isUrgentString = isUrgentString;
		this.interviewString=interviewString;
		this.genderString = genderString;
		this.detailString = detailString;
		this.requiredAgeInt=requiredAgeInt;
	}

	public String getDetailString() {
		return detailString;
	}

	public void setDetailString(String detailString) {
		this.detailString = detailString;
	}

	public String getTaskString() {
		return taskString;
	}

	public void setTaskString(String taskString) {
		this.taskString = taskString;
	}

	public String getDateString() {
		return dateString;
	}

	public void setDateString(String dateString) {
		this.dateString = dateString;
	}

	public String getSeatNumberString() {
		return seatNumberString;
	}

	public void setSeatNumberString(String seatNumberString) {
		this.seatNumberString = seatNumberString;
	}

	public String getPlaceString() {
		return placeString;
	}

	public void setPlaceString(String placeString) {
		this.placeString = placeString;
	}

	public String getCityString() {
		return cityString;
	}

	public void setCityString(String cityString) {
		this.cityString = cityString;
	}

	public String getQualificationString() {
		return qualificationString;
	}

	public void setQualificationString(String qualificationString) {
		this.qualificationString = qualificationString;
	}

	public String getEnrollmentString() {
		return enrollmentString;
	}

	public void setEnrollmentString(String enrollmentString) {
		this.enrollmentString = enrollmentString;
	}

	public String getSupportProvidedString() {
		return supportProvidedString;
	}

	public void setSupportProvidedString(String supportProvidedString) {
		this.supportProvidedString = supportProvidedString;
	}

	public String getIsRemoteString() {
		return isRemoteString;
	}

	public void setIsRemoteString(String isRemoteString) {
		this.isRemoteString = isRemoteString;
	}

	public String getIsUrgentString() {
		return isUrgentString;
	}

	public void setIsUrgentString(String isUrgentString) {
		this.isUrgentString = isUrgentString;
	}

	public String getGenderString() {
		return genderString;
	}

	public void setGenderString(String genderString) {
		this.genderString = genderString;
	}

	public int getRequiredAgeInt() {
		return requiredAgeInt;
	}

	public void setRequiredAgeInt(int requiredAgeInt) {
		this.requiredAgeInt = requiredAgeInt;
	}
	
	public String getInterviewString() {
		return interviewString;
	}

	public void setInterviewString(String interviewString) {
		this.interviewString = interviewString;
	}

	
	
	
}
