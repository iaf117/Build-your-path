import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class registeredUsers extends JFrame {

	private JPanel contentPane;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	
			public static void run() {
				try {
					registeredUsers frame = new registeredUsers();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		

	/**
	 * Create the frame.
	 */
	public registeredUsers() {
		setTitle("Registered Users");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIsRemote_2 = new JLabel("registered users");
		lblIsRemote_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblIsRemote_2.setBounds(78, 74, 114, 14);
		contentPane.add(lblIsRemote_2);
		
		comboBox = new JComboBox();
		comboBox.setBounds(191, 70, 161, 22);
		contentPane.add(comboBox);
		
		try {
			comboBox.setModel(new DefaultComboBoxModel(newUser.getItems().toArray()));
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		comboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					newUser user=null;
					String email = String.valueOf(comboBox.getSelectedItem());
					try {
						 user= newUser.getUserData(email);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "user Information: \nuser first name: "+user.getFnameString()+"\n"+"user middle name: "+user.getMnameString()
					        +"\n"+"last name: "+user.getLnameString()
							+"\n"+"user email: "+email+"\n"+"user city: "+user.getCityString()
							+"\n"+"user country: "+user.getCountryString()+"\n"+"user age: "+user.getAgeInt()
							+"\n"+"user phone: "+user.getPhoneString()+"\n"+"user education: "+user.getEducationString()
							+"\n"+"work experince: "+user.getWorkExpString()+"\n"+"skill : "+user.getskillsString());
				
			}
		});
		
		JButton btnAccept = new JButton("accept");
		btnAccept.setBounds(129, 146, 74, 23);
		btnAccept.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "User Accepted!");
			}
		});
		contentPane.add(btnAccept);
		
		JButton btnDeny = new JButton("deny");
		btnDeny.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newUser.delete(String.valueOf(comboBox.getSelectedItem()));
				try {
					comboBox.setModel(new DefaultComboBoxModel(newUser.getItems().toArray()));
					JOptionPane.showMessageDialog(null, "User Denied!");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnDeny.setBounds(229, 146, 74, 23);
		contentPane.add(btnDeny);
	}

}
